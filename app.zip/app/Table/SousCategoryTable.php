<?php
namespace App\Table;

use Core\Table\Table;

class SousCategoryTable extends Table{

    protected $table = "sous_categories";

}