<h1><?= $article->titre; ?></h1>

<p><em><?= $article->categorie; ?></em></p>

<p><?= $article->contenu; ?></p>