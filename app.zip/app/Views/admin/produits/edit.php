<form method="post" enctype="multipart/form-data">

    <?= $form->input('titre', 'Titre de l\'article'); ?>

    <?= $form->input('img', 'image du produit', ['type' => 'file']); ?>

    <?= $form->input('description', 'description', ['type' => 'textarea']); ?>

    <?= $form->input('prix', 'prix', ['type' => 'number']); ?>

    <?= $form->select('category_id', 'Catégorie', $categories); ?>

    <button class="btn btn-primary">Sauvegarder</button>
</form>