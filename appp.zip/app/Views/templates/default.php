<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title><?= App::getInstance()->title; ?></title>
    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../public/css/style.css" rel="stylesheet">

    <script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" defer></script>

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="index.php">logo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="index.php">Accueil</a>
        <a class="nav-link" href="index.php?p=produits.index">Produits</a>
        
        <?php 
        if(isset($_SESSION['auth']) && !empty($_SESSION['auth'])){?>
        <a class="nav-link" href="index.php?p=users.logout">Déconnexion</a>
        <?php }else{?>
        <a class="nav-link" href="index.php?p=users.login">Connexion</a>
        <?php }?>
        
        <a class="nav-link" href="index.php?p=users.inscription">Inscription</a> 

        <a class="nav-link" href="index.php?p=panier.index">panier</a> 

      </div>
    </div>
  </div>
</nav>

<?php 
  if(isset($_SESSION['auth']) && !empty($_SESSION['auth']) && $_SESSION['user']->role == 'ROLE_ADMIN' ){
?>
  <nav>
    <ul>
      <li><a class="nav-link" href="index.php?p=admin.posts.index">Articles</a></li>
      <li><a class="nav-link" href="index.php?p=admin.produits.index">Produits</a></li>
      <li><a class="nav-link" href="index.php?p=admin.categories.index">categories</a></li>
      <li><a class="nav-link" href="index.php?p=admin.souscategories.index">Sous categories</a></li>
    </ul>
  </nav>

<?php
  }
?>

<div class="container">
    <div class="starter-template" style="padding-top: 100px;">
        <?= $content; ?>
    </div>

</div><!-- /.container -->


</body>
</html>
