<h1><?= $produit->titre; ?></h1>

<img src="../public/img/upload/<?= $produit->img; ?>" style="width: 10%;">

<p><?= $produit->description; ?></p>


