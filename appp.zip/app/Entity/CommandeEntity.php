<?php
namespace App\Entity;

use Core\Entity\Entity;

class CommandeEntity extends Entity{


}